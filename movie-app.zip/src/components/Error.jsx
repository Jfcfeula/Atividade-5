export default function Error({ message }) {
  return <div className="text-red-500 text-center mt-5">{message}</div>;
}
