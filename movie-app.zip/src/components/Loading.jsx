export default function Loading() {
  return <div className="text-white text-center mt-5">Carregando...</div>;
}
